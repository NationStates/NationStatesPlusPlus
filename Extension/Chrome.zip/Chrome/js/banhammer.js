(function(){
	if (getVisiblePage() == "blank" && typeof $.QueryString["banhammer"] != "undefined") {
		$.QueryString["banhammer"]
	}
})();

